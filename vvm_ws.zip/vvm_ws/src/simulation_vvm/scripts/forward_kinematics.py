import numpy as np
import math

def degrees_to_radians(degrees):
    return math.radians(float(degrees))

theta1 = degrees_to_radians(input("Enter theta 1 (in degrees): "))
theta2 = degrees_to_radians(input("Enter theta 2 (in degrees): "))
theta3 = degrees_to_radians(input("Enter theta 3 (in degrees): "))
theta4 = degrees_to_radians(input("Enter theta 4 (in degrees): "))

H1 = np.array([[math.cos(theta1),0,math.sin(theta1),0],
               [math.sin(theta1),0,-math.cos(theta1),0],
               [0,1,0,0.077],
               [0,0,0,1]])

H2 = np.array([[math.cos(theta2),-math.sin(theta2),0,0],
               [math.sin(theta2),math.cos(theta2),0,0],
               [0,0,1,0],
               [0,0,0,1]])

H2T = np.array([[1,0,0,0.024],
               [0,1,0,0.128],
               [0,0,1,0],
               [0,0,0,1]])


H3 = np.array([[math.cos(theta3),-math.sin(theta3),0,0.124*math.cos(theta3)],
               [math.sin(theta3),math.cos(theta3),0,0.124*math.sin(theta3)],
               [0,0,1,0],
               [0,0,0,1]])

H4 = np.array([[math.cos(theta4),-math.sin(theta4),0,0.126*math.cos(theta4)],
               [math.sin(theta4),math.cos(theta4),0,0.126*math.sin(theta4)],
               [0,0,1,0],
               [0,0,0,1]])

H12 = np.dot(H1,H2)
H12T=np.dot(H12,H2T)
H123 = np.dot(H12T,H3)
H1234 = np.dot(H123,H4)

X = H1234[0,3]
Y = H1234[1,3]
Z = H1234[2,3]


#Print End-effector's Coordinates
print ("*************************")
print ("{:21s}".format("x-coordinate"), "{0:.5f}".format(H1234[0, 3]))
print ("{:21s}".format("y-coordinate"), "{0:.5f}".format(H1234[1, 3]))
print ("{:21s}".format("z-coordinate"), "{0:.5f}".format(H1234[2, 3]))


import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
from rclpy import qos
import math
import sys

'''
+-----------------------+--------------+--------------+----------+--+
| Transformation Matrix |              |              |          |  |
+-----------------------+--------------+--------------+----------+--+
| cosθ                  | -cosα * sinθ | sinα * sinθ  | a * cosθ |  |
| sinθ                  | cosα * cosθ  | -sinα * cosθ | a * sinθ |  |
| 0                     | sinα         | cosα         | d        |  |
| 0                     | 0            | 0            | 1        |  |
+-----------------------+--------------+--------------+----------+--+
+-------------------+-----------------------------+------------------+-----------------------------+--+
|  θ (about Z axis) |      d (along Z axis)       | α (about X axis) |      a (along X axis)       |  |
+-------------------+-----------------------------+------------------+-----------------------------+--+
| theta_base        | d0 (base to shoulder - 2.5) | π/2              | 0                           |  |
| theta_shoulder    | 0                           | 0                | a1 (shoulder to elbow - 12) |  |
| theta_elbow       | 0                           | π/2              | 0                           |  |
| 0                 | d3 (elbow to end - 9.5)     | 0                | 0                           |  |
+-------------------+-----------------------------+------------------+-----------------------------+--+
'''

#Transformation Matrix Calculated Parameters
theta = []      #Since it will be user input
d = [2.5, 0, 0, 9.5]
alpha = [math.pi/2,0, math.pi/2, 0]
a = [0, 12, 0, 0]
joint = [0.0, 0.0, 0.0, 0.0, 0.0]  

def forward_kinematics_publisher():

    global node
    Joints = node.create_publisher(Float64MultiArray, '/forward_position_controller/commands',qos_profile=qos.qos_profile_parameter_events)
    
    joint = Float64MultiArray()
    joint.data = [0.0,0.0,0.0,0.0,0.0]

    if 0.0 <= theta_base <= 180.0 and 0.0 <= theta_shoulder <= 180.0 and 0.0 <= theta_elbow <= 180.0: 
        joint.data[0] =(theta_base)*math.pi/180
        joint.data[1] = (theta_shoulder)*math.pi/180
        joint.data[2] = (theta_elbow)*math.pi/180
        if gripper_open:
            joint.data[3] = 0.8
            joint.data[4] = 0.8
        else:
            joint.data[3] = 0.0
            joint.data[4] = 0.0

        print("\ntheta_base = ", joint.data[0], "\n", "theta_shoulder = " , joint.data[1], "\n", "theta_elbow = " , joint.data[2], "\n", "Gripper Open = " , gripper_open, "\n")

        print ("=========================\n")

    else:
        print ("Enter angles in range 0 to 180")

    Joints.publish(joint)

if __name__ == '__main__':
    rclpy.init(args=sys.argv)
    global node 
    node = Node('forward_kinematics_publisher')
    node.create_timer(0.2, forward_kinematics_publisher)
    rclpy.spin(node)
    rclpy.shutdown()