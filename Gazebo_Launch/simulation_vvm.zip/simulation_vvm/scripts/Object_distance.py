#!/usr/bin/python3

''' Subsribe from forward_position_controller/commands and publish to forward kinematics.py '''

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray

class PositionCommandSubscriber(Node):
    def __init__(self):
        super().__init__('position_command_subscriber')
        self.subscription = self.create_subscription(
            Float64MultiArray,
            'forward_position_controller/commands',
            self.listener_callback,
            10)
        self.subscription  

    def listener_callback(self, msg):
        if len(msg.data) == 6:
            joint_positions = {
                "Joint 1": msg.data[0],
                "Joint 2": msg.data[1],
                "Joint 3": msg.data[2],
                "Joint 4": msg.data[3],
                "Joint 5": msg.data[4],
                "Joint 6": msg.data[5],
            }
            print("Joint 1 - ",msg.data[0])
            print("Joint 2 - ",msg.data[1])
            print("Joint 3 - ",msg.data[2])
            print("Joint 4 - ",msg.data[3])
            print("Joint 5 - ",msg.data[4])
            print("Joint 6 - ",msg.data[5])
        else:
            print("ERROR RECIEVING VALUES ")

    
    


def main(args=None):
    rclpy.init(args=args)
    node = PositionCommandSubscriber()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
