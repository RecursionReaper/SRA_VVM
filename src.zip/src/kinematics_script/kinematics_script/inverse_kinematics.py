#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
from rclpy import qos
import numpy as np
import math

class InverseKinematicsPublisher(Node):

    def __init__(self):
        super().__init__('inverse_kinematics_publisher')
        self.publisher = self.create_publisher(Float64MultiArray, '/forward_position_controller/commands', qos_profile=qos.qos_profile_parameter_events)
        self.timer = self.create_timer(0.2, self.publish_joint_positions)

        self.L1 = 0.077
        self.L2z = 0.128
        self.L2x = 0.024
        self.L2 = 0.130
        self.L3 = 0.124
        self.L4 = 0.126

    def take_input(self):
        self.get_logger().info("Enter X coordinate:")
        self.EEX = float(input())
        self.get_logger().info("Enter Y coordinate:")
        self.EEY = float(input())
        self.get_logger().info("Enter Z coordinate:")
        self.EEZ = float(input())

    def calculate_joint_angles(self):
        alpha = math.atan((self.EEZ - self.L1) / (math.sqrt((self.EEX * self.EEX) + (self.EEY * self.EEY))))

        translation_matrix = np.array([
            [1, 0, 0, self.EEX],
            [0, 1, 0, self.EEY],
            [0, 0, 1, self.EEZ - self.L1],
            [0, 0, 0, 1]
        ])

        rotation_matrix = np.array([
            [math.cos(alpha), -math.sin(alpha), 0, 0],
            [math.sin(alpha), math.cos(alpha), 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ])

        end_effector_matrix = np.dot(translation_matrix, rotation_matrix)
        orientation_matrix = end_effector_matrix[:3, :3]

        if self.is_point_accessible():
            if self.EEX == 0:
                T1 = 1.5708
            else:
                T1 = math.atan(self.EEY / self.EEX)

            Calc_Var_A = (self.EEX / math.cos(T1)) - (self.L4 * math.cos(alpha))
            Calc_Var_B = (self.EEZ - self.L1) - (self.L4 * math.sin(alpha))

            T3 = math.asin(((Calc_Var_A * Calc_Var_A) + (Calc_Var_B * Calc_Var_B) - (self.L3 * self.L3) - (self.L2 * self.L2)) / (2 * self.L2 * self.L3)) - math.atan(self.L2x / self.L2z)

            Calc_Var_C1 = (self.L3 * math.sin(T3) + self.L2 * math.cos(math.atan(self.L2x / self.L2z)))
            Calc_Var_C2 = (self.L3 * math.cos(T3) + self.L2 * math.sin(math.atan(self.L2x / self.L2z)))

            Calc_Var_A_Bar = Calc_Var_A / (math.sqrt((Calc_Var_C1 * Calc_Var_C1) + (Calc_Var_C2 * Calc_Var_C2)))
            Calc_Var_B_Bar = Calc_Var_B / (math.sqrt((Calc_Var_C1 * Calc_Var_C1) + (Calc_Var_C2 * Calc_Var_C2)))

            T2 = math.atan(Calc_Var_C2 / Calc_Var_C1) - math.atan(Calc_Var_A_Bar / Calc_Var_B_Bar)
            T4 = alpha - T2 - T3

            return [math.degrees(T1), math.degrees(T2), math.degrees(T3), math.degrees(T4)]
        else:
            return None

    def is_point_accessible(self):
        distance_check = (self.EEX**2) + ((self.EEZ - self.L1)**2) + (self.EEY**2)
        reachability_check = (self.L2 + self.L3 + self.L4)**2
        return self.EEX >= 0 and self.EEZ >= 0 and distance_check <= reachability_check

    def publish_joint_positions(self):
        self.take_input()
        joint_angles = self.calculate_joint_angles()

        if joint_angles:
            joint_msg = Float64MultiArray()
            joint_msg.data = joint_angles
            self.publisher.publish(joint_msg)
            self.get_logger().info("Joint angles published successfully.")
        else:
            self.get_logger().warn("The point is not reachable. Please enter points within the range.")

def main(args=None):
    rclpy.init(args=args)
    node = InverseKinematicsPublisher()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
